# Customer Science GTM Plays (Static)
This is a static site. Deploy by dropping the folder (or the provided zip) into Netlify.

## Netlify settings
- Build command: (none)
- Publish directory: /
